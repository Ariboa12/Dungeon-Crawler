'''Explanation of my game:   '''


# from cmu_graphics import *
# from Prims import *
# from MainBoard import*
# class Character:
# from mainChar import*
# def OnAppStart(app):

# def redrawAll(app):
