from cmu_graphics import *
from Prims import *
from PIL import *
import os, pathlib
def onAppStart(app):
    app.rows = 3
    app.cols = 3
    app.mainChar = Image.open('images/mainChar.jpg')
    app.mainChar = CMUImage(app.mainChar)
    app.enemy = Image.open('images/enemy.jpg')
    app.enemy = CMUImage(app.enemy)
    app.graph = Graph(app.rows, app.cols)
    app.finalMoves = prim(app.graph)
    print(app.finalMoves)
    app.width = 600
    app.height = 600
    app.nodeSize = 50
    app.map = True
    app.boardLeft = 20
    app.boardTop = 20
    app.boardWidth = 600
    app.boardHeight = 600
    app.cellBorderWidth = 2
    heroPos = getNodePosition(app, 0, 0)
    app.hero = Character(heroPos, app.mainChar)  # Initial position of hero at node (0,0)
    app.enemies = []
    app.enemiesTouched = set()
    app.currentNode = (0, 0)  # Track the current node position of the hero

    #Generate random position for enemies
    numEnemies = 2
    for x in range(numEnemies):
        # keep looping and make sure to not have same position as the other enemy and the hero
        while True:
            row = random.randint(0, app.rows - 1)
            col = random.randint(0, app.cols - 1)
            if (row, col) != app.currentNode and (row, col) not in [enemy.getPosition() for enemy in app.enemies]:
                enemyPos = getNodePosition(app, row, col)
                app.enemies.append(Enemy(enemyPos, app.enemy))
                break


def getNodePosition(app, row, col):
    cellWidth, cellHeight = getCellSize(app)
    x = app.boardLeft + col * cellWidth + (cellWidth - 20) / 2
    y = app.boardTop + row * cellHeight + (cellHeight - 20) / 2
    return (x, y)

def drawBoard(app):
    for row in range(app.rows):
        for col in range(app.cols):
            drawCell(app, row, col)

def drawBoardBorder(app):
    drawRect(app.boardLeft, app.boardTop, app.boardWidth, app.boardHeight,
             fill=None, border='black',
             borderWidth=2 * app.cellBorderWidth)

def drawCell(app, row, col):
    cellLeft, cellTop = getCellLeftTop(app, row, col)
    cellWidth, cellHeight = getCellSize(app)
    drawRect(cellLeft, cellTop, cellWidth, cellHeight,
             fill=None, border='black',
             borderWidth=app.cellBorderWidth)

def getCellLeftTop(app, row, col):
    cellWidth, cellHeight = getCellSize(app)
    cellLeft = app.boardLeft + col * cellWidth
    cellTop = app.boardTop + row * cellHeight
    return (cellLeft, cellTop)

def getCellSize(app):
    cellWidth = app.boardWidth / app.cols
    cellHeight = app.boardHeight / app.rows
    return (cellWidth, cellHeight)

def drawPrims(app):
    for startpoints, endpoints in app.finalMoves.items():
        #x1, y1 = startpoints[1] * (app.width // app.cols), startpoints[0] * (app.height // app.rows)
        x1, y1 = getNodePosition(app, startpoints[1], startpoints[0])
        for endpoint in endpoints:
            #x2, y2 = endpoint[1] * (app.width // app.cols), endpoint[0] * (app.height // app.cols)
            x2, y2 = getNodePosition(app, endpoint[1], endpoint[0])
            drawLine(x1 + 30, y1 + 30, x2 + 30, y2 + 30)
            #drawRect((pointX * (app.width // app.cols)) + 30, (pointY * (app.height // app.rows)) + 30, app.nodeSize, app.nodeSize, fill='red', border='black', align='center')

def redrawAll(app):
    if app.map:
        drawPrims(app)
    for node in app.graph.keys():
        nodePos = getNodePosition(app, node[0], node[1])
        #n = Node(node[0] * ((app.width // app.cols)) + 30, ((node[1] * (app.height // app.rows)) + 30), app.width / 20)
        n = Node(nodePos[0], nodePos[1], app.width / 20)
        n.drawNode()
    app.hero.drawCharacter()
    for enemy in app.enemies:
        enemy.drawCharacter()

def onKeyPress(app, key):
    #print("current pos is ", app.currentNode)
    validMoves = getValidMoves(app)
    if validMoves:
        if key == 'm':
            app.map = not app.map
        if key == 'left' and 'left' in validMoves:
            moveCharacter(app, -1, 0)
        elif key == 'right' and 'right' in validMoves:
            moveCharacter(app, 1, 0)
        elif key == 'up' and 'up' in validMoves:
            moveCharacter(app, 0, -1)
        elif key == 'down' and 'down' in validMoves:
            moveCharacter(app, 0, 1)
    checkCollision(app)


def getValidMoves(app):
    row, col = app.currentNode
    moves = {
        'left': (row, col - 1),
        'right': (row, col + 1),
        'up': (row - 1, col),
        'down': (row + 1, col)
    }
    validMoves = []
    for direction, (newrow, newcol) in moves.items():
        v = app.finalMoves[(col,row)]
        for m, n in v:
            #print(" final moves m=", m , " n = ", n)
            if m == newcol and n == newrow:
                #print("Adding " ,direction,  " to valid moves")
                validMoves.append(direction)
    return validMoves

def getValidMoves2(app):
    row, col = app.currentNode
    moves = {
        'left': (row, col - 1),
        'right': (row, col + 1),
        'up': (row - 1, col),
        'down': (row + 1, col)
    }
    validMoves = []
    for direction, (r, c) in moves.items():
        if (r, c) in app.finalMoves:
            #print("new row =", r, " new col=", c)
            validMoves.append(direction)
            #print("Adding " ,direction,  " to valid moves")
    return validMoves

def moveCharacter(app, dcol, drow):
    newRow, newCol = app.currentNode[0] + drow, app.currentNode[1] + dcol
    if (newRow, newCol) in app.finalMoves:
        app.currentNode = (newRow, newCol)
        newPos = getNodePosition(app, newRow, newCol)
        app.hero.moveTo(newPos)

#def moveCharacter(app, dcol, drow):
#    newRow, newCol = app.currentNode[0] + drow, app.currentNode[1] + dcol
#    if (newRow, newCol) in app.finalMoves:
#        app.currentNode = (newRow, newCol)
#        newPos = getNodePosition(app, newRow, newCol)
#        print("new pos is " , newRow, " ", newCol)
#        app.hero.moveTo(newPos)

#just use key press
#def onKeyRelease(app, key):
#    if key == 'm':
#        app.map = not app.map

def checkCollision(app):
    for enemy in app.enemies:
        if app.hero.collidesWith(enemy):
            print("Hero touched an enemy!")
            #put in a set so that we can keep track of distinct enemies touched
            app.enemiesTouched.add(enemy)
            
            #stop when all enemies are touched
            if (len(app.enemiesTouched) == len(app.enemies)):
                app.stop()

class Node:
    def __init__(self, x, y, size):
        self.x = x
        self.y = y
        self.size = size
        self.unit = 10

    def drawNode(self):
        drawRect(self.x, self.y, self.size, self.size, fill=None, border='Black')

class Character:
    def __init__(self, pos, spritePath):
        self.x, self.y = pos
        self.spritePath = spritePath

    def drawCharacter(self):
        drawImage(self.spritePath, self.x, self.y, width=50, height=50)

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def moveTo(self, pos):
        self.x, self.y = pos

    def collidesWith(self, other):
        spriteWidth = 50  # Assuming a width of 50 pixels for sprites
        spriteHeight = 50  # Assuming a height of 50 pixels for sprites
        return (self.x < other.x + spriteWidth and
                self.x + spriteWidth > other.x and
                self.y < other.y + spriteHeight and
                self.y + spriteHeight > other.y)

    def getPosition(self):
        return (self.x, self.y)
    
class Enemy(Character):
    pass

def main():
    runApp()

if __name__ == '__main__':
    main()
