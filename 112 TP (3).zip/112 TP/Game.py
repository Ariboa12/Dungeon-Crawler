'''Explanation of my game: This game is a dungeon crawler where you are in random rooms connected with nodes.
    each room spawns 2-5 enemies and the enemies have a basic ai in which they 
    try to chase you. there is a boss room and if you defeat the boss, you win.  '''
