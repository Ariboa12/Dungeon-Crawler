from cmu_graphics import *
from Prims import *
# drawing with prims, help given by chatGPT

def onAppStart(app):
    app.rows = 3
    app.cols = 3
    app.points = list
    app.graph = Graph(app.rows,app.cols)
    app.finalMoves = prim(app.graph)
    print(app.finalMoves)
    app.width = 800
    app.height = 800
    app.nodeSize = 50
    app.map = False
    app.boardLeft = 50
    app.boardTop = 75
    app.boardWidth = 300
    app.boardHeight = 300
    app.cellBorderWidth = 2
    app.offsetX = 0
    app.offsetY = 0

def drawBoard(app):
    for row in range(app.rows):
        for col in range(app.cols):
            drawCell(app, row, col)

def drawBoardBorder(app):
  # draw the board outline (with double-thickness):
  drawRect(app.boardLeft, app.boardTop, app.boardWidth, app.boardHeight,
           fill=None, border='black',
           borderWidth=2*app.cellBorderWidth)

def drawCell(app, row, col):
    cellLeft, cellTop = getCellLeftTop(app, row, col)
    cellWidth, cellHeight = getCellSize(app)
    drawRect(cellLeft, cellTop, cellWidth, cellHeight,
             fill=None, border='black',
             borderWidth=app.cellBorderWidth)

def getCellLeftTop(app, row, col):
    cellWidth, cellHeight = getCellSize(app)
    cellLeft = app.boardLeft + col * cellWidth
    cellTop = app.boardTop + row * cellHeight
    return (cellLeft, cellTop)

def getCellSize(app):
    cellWidth = app.boardWidth / app.cols
    cellHeight = app.boardHeight / app.rows
    return (cellWidth, cellHeight)

def drawPrims(app):
    for startpoints,endpoints in app.finalMoves.items():
        x1,y1 = startpoints[1] * (app.width//app.cols),startpoints[0]*(app.height//app.rows)
        for endpoint in endpoints:
            x2,y2 = endpoint[1] * (app.width//app.cols),endpoint[0]*(app.height//app.cols)
            drawLine(x1+30,y1+30,x2+30,y2+30)
            #check if its vertical or horizontal
            # check first horizontal then vertical
            # if x1 != x2:
            #     drawConnector(,x,y,height,width)
            # y1 != y2:
            #     drawConnector(y,x,height,width)
def drawPoints(app):
       
        for (pointX,pointY) in app.graph.keys():
            drawRect((pointX*(app.width//app.cols))+30,(pointY*(app.height//app.rows))+30,app.nodeSize,app.nodeSize,fill = 'red',border = 'black',align = 'center')
   
def redrawAll(app):
    if app.map == True:
        drawPrims(app)
        drawPoints(app)
    for node in app.graph.keys():
        #make each node big enough for the character to have a wide space to move 
        # and for each enemy to generate
        n=Node(node[0]*((app.width//app.cols)) + 30 ,((node[1]*(app.height//app.rows))+30), app.width/20)
        n.drawNode()
def onKeyHold(app,key):
    if key == 'm':
        app.map = not app.map
def onKeyRelease(app,key):
     if key == 'm':
        app.map = not app.map
#draw true map
#using oop, idea given by chatGPT
class Node:
    # this gives the node of each map, a node is represented by a board, probably 5x5
    # for each node, we draw a connector and the connector is represented by a rectangle
    # we can move within a node and it is where most of the action happens
    # when we enter a node, a random number of enemies spawn
            # make each node big enough for the characters to move 
    def __init__(self,x,y,size):
        self.x = x
        self.y = y
        self.size = size
        self.unit =10
    def __eq__(self,other):
        self.size == other.size
        self.x == other.x
        self.y == other.y
    def drawNode(self):
        drawRect(self.x,self.y,self.size,self.size,fill = None,border = 'Black')
    
    
class Connector(Node):
    #get connectors to work
    def __init__(self,x,y,size):
        super().__init__(x,y)
        pass
        def getConnectInfo(self):
            pass
            #get Top,left,width,height
        def drawConnector(self,app):
            top,left,width,height = getConnectInfo(self)
            drawRect(top,left,width,height)
class Character:
    #work on these
    pass

class Enemy(Character):
    
    pass
def main():
    runApp()

if __name__ == '__main__':
    main()  

