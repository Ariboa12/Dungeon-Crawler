from cmu_cpcs_utils import testFunction
import collections
import random
from Prims import*
def getCellSize(app):
    cellWidth = app.boardWidth / app.cols
    cellHeight = app.boardHeight / app.rows
    return (cellWidth, cellHeight)

def getGridNode(app,pos):
    cellWidth, cellHeight = getCellSize(app)
    col = (pos[0] - app.boardLeft) // cellWidth
    row = (pos[1] - app.boardTop) // cellHeight
    return int(row), int(col)

def getValidMoves(app,node):
    row, col = app.currentNode
    moves = {
        'left': (row, col - 1),
        'right': (row, col + 1),
        'up': (row - 1, col),
        'down': (row + 1, col)
    }
    validMoves = []
    for direction, (newrow, newcol) in moves.items():
        v = app.finalMoves[(col,row)]
        for m, n in v:
            if m == newcol and n == newrow:
                validMoves.append(direction)
    return validMoves

class App:
    def __init__(self):
        self.x = 0
        self.y = 1
        self.boardWidth = 5
        self.boardHeight = 5
    def getPosition(self):
        return (self.x, self.y)
    
# def pathToHero(app,start,end,board):
#     start = getGridNode(app,app.getPosition())
#     goal = app.currentNode
#     queue = collections.deque([[start]])
#     visited = set()

#     while queue:
#         path = queue.popleft()
#         x, y = path[-1]
#         if (x, y) == goal:
#             return path[1:]
#         if (x, y) not in visited:
#             for direction in getValidMoves(app,(x,y)):
#                 dx, dy = {'left': (0, -1), 'right': (0, 1), 'up': (-1, 0), 'down': (1, 0)}[direction]
#                 nextNode = (x + dx, y + dy)
#                 if nextNode not in visited:
#                     newPath = list(path)
#                     newPath.append(nextNode)
#                     queue.append(newPath)
#                 visited.add((x, y))
#         return []

#     return path

def pathToHero(app,start,end, board):
    start = start
    goal = end
    queue = collections.deque([start])
    visited = {start}
    prev = dict()
    dir = ['left', 'right', 'up', 'down']
    while queue:
        curNode = queue.popleft()
        x, y = curNode
        if (x, y) == goal:
            break
        for nextNode in board[curNode]:
            if nextNode not in visited:
                queue.append(nextNode)
                prev[nextNode] = curNode
                visited.add(nextNode)
    path = []
    cur = goal
    while (cur != start):
        path.append(cur)
        cur = prev[cur]
    path.append(start)
    return path[::-1]
###testFunction###
@testFunction
def testpathToHero():
    app = App()
    app.currentNode = (0,0)
    app.boardLeft = 20
    app.boardTop = 20
    app.rows = 5
    app.cols = 5
    app.boardWidth = 600
    app.boardHeight = 600
    board = [[(0,0),(0,1),(0,2),(0,3),(0,4)],
            [(1,0),(1,1),(1,2),(1,3),(1,4)],
            [(2,0),(2,1),(2,2),(2,3),(2,4)],
            [(3,0),(3,1),(3,2),(3,3),(3,4)],
            [(4,0),(4,1),(4,2),(4,3),(4,4)]]
    graph = Graph(app.rows,app.cols)
    app.finalMoves = {(1, 0): {(2, 0), (0, 0)}, (0, 0): {(1, 0), (0, 1)}, (0, 1): {(1, 1), (0, 2), (0, 0)}, (0, 2): {(0, 1), (0, 3)}, (2, 0): {(1, 0), (2, 1)}, (2, 1): {(3, 1), (2, 0), (2, 2)}, (3, 1): {(3, 2), (4, 1), (2, 1), (3, 0)}, (2, 2): {(1, 2), (2, 1)}, (0, 3): {(1, 3), (0, 2), (0, 4)}, (0, 4): {(0, 3), (1, 4)}, (3, 2): {(3, 1), (4, 2)}, (1, 4): {(2, 4), (0, 4)}, (3, 0): {(3, 1), (4, 0)}, (4, 0): {(3, 0)}, (1, 1): {(0, 1)}, (1, 2): {(2, 2)}, (1, 3): {(2, 3), (0, 3)}, (4, 1): {(3, 1)}, (2, 3): {(3, 3), (1, 3)}, (2, 4): {(3, 4), (1, 4)}, (3, 3): {(2, 3), (4, 3)}, (4, 2): {(3, 2)}, (4, 3): {(4, 4), (3, 3)}, (4, 4): {(4, 3)}, (3, 4): {(2, 4)}}
    assert(pathToHero(app,(0,0),(1,0),board = app.finalMoves) == [(0,0),(1,0)])
    assert(pathToHero(app,(0,0),(2,0),board = app.finalMoves) == [(0,0),(1,0),(2,0)])
    assert(pathToHero(app,(0,0),(1,1),board = app.finalMoves) == [(0,0),(0,1),(1,1)])
    assert (pathToHero(app,(0,0),(0,4),board = app.finalMoves) == [(0,0),(0,1),(0,2),(0,3),(0,4)])
    print(pathToHero(app,(0,1),(2,4),board = app.finalMoves))
    assert (pathToHero(app,(0,1),(2,4),board = app.finalMoves) == [(0,0),(0,1),(0,2),(1,2),(1,3),(2,3),(2,4)])
    return ('passed:)')
testpathToHero()