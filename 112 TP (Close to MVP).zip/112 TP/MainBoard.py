from cmu_graphics import *
from Prims import *
from PIL import *
import os, pathlib
import random
import collections
#BFS algorithm explained from chat.gpt
#redone by samuel precollege student
#debugging on basic movement explained by chatgpt
#background resized using https://imageresizer.com/
#background gotten from https://www.craiyon.com/image/_8PrOI3bQLGVvjOlkJ50_A
def onAppStart(app):
    app.rows = 5
    app.cols = 5
    app.margin = 5
    # Open image from local directory
    # Image.open
    app.gameBack = openImage(r"C:\Users\emoji\OneDrive\Desktop\112 TP\Images\Dungeon2 (2).jpg")
    app.gameBack = CMUImage(app.gameBack)
    app.mainChar = Image.open(r"C:\Users\emoji\OneDrive\Desktop\112 TP\Images\mainChar.jpg")
    app.mainChar = CMUImage(app.mainChar)
    app.enemy = Image.open(r"C:\Users\emoji\OneDrive\Desktop\112 TP\Images\Enemy.jpg")
    app.enemy = CMUImage(app.enemy)
    #
    app.graph = Graph(app.rows, app.cols)
    app.finalMoves = prim(app.graph)
  
    app.width = 800
    app.height = 800
    app.nodeSize = 100
    app.map = True
    app.boardLeft = 20
    app.boardTop = 20
    app.boardWidth = 600
    app.boardHeight = 600
    app.cellBorderWidth = 2
    app.lineWidth= 100
    app.numEnemies = 4
    app.currNode = (0,0)
    #win conditions
    app.win = False
    app.lose = False
    app.moving = False
    app.enemiesTouched = set()
    heroPos = getNodePosition(app, 0, 0)
    app.hero = Character(heroPos, app.mainChar)
    app.heroX,app.heroY = heroPos
      # Initial position of hero at node (0,0)
    app.enemies = []
   
    app.lastNodePosition = (app.rows-1,app.cols-1)
    # Track the current node position of the hero

    #Generate random position for enemies
    enemyPositions  = set()
    # this was a fix, given by chat.gpt
    while len(enemyPositions) < app.numEnemies:
        row , col = random.choice(list(app.graph.keys()))
        if (row,col)!= app.currNode and (row,col) not in enemyPositions:
            enemyPositions.add((row,col))
    for (row,col) in enemyPositions:
        enemyPos = getNodePosition(app,row,col)
        app.enemies.append(Enemy(enemyPos,(row,col),app.enemy))
    app.health = len(app.enemies)
    app.enemyMoveInterval = 1000
    app.enemyTimer = app.enemyMoveInterval
    app.spriteCounter = 0
    app.stepsPerSecond = 10
def openImage(fileName):
        return Image.open(os.path.join(pathlib.Path(__file__).parent,fileName))


    
def onStep(app):
    if app.moving:
        app.hero.updatePosition()
    for enemy in list(app.enemies):
        enemy.updatePosition()
    app.timerDelay = 100
    app.enemyTimer -= app.timerDelay

    if app.enemyTimer <= 0:
        for enemy in app.enemies:
            enemy.enemyAI(app)
        app.enemyTimer = app.enemyMoveInterval
    checkCollision(app)

def getNodePosition(app, row, col):
    cellWidth, cellHeight = getCellSize(app)
    x = app.boardLeft + col * cellWidth + (cellWidth - 20) / 2
    y = app.boardTop + row * cellHeight + (cellHeight - 20) / 2
    return (x, y)

def drawBoard(app):
    for row in range(app.rows):
        for col in range(app.cols):
            drawCell(app, row, col)

def drawBoardBorder(app):
    drawRect(app.boardLeft, app.boardTop, app.boardWidth, app.boardHeight,
             fill=None, border='black',
             borderWidth=2 * app.cellBorderWidth)

def drawCell(app, row, col):
    cellLeft, cellTop = getCellLeftTop(app, row, col)
    cellWidth, cellHeight = getCellSize(app)
    drawRect(cellLeft, cellTop, cellWidth, cellHeight,
             fill=None, border='black',
             borderWidth=app.cellBorderWidth)

def getCellLeftTop(app, row, col):
    cellWidth, cellHeight = getCellSize(app)
    cellLeft = app.boardLeft + col * cellWidth
    cellTop = app.boardTop + row * cellHeight
    return (cellLeft, cellTop)

def getCellSize(app):
    cellWidth = app.boardWidth / app.cols
    cellHeight = app.boardHeight / app.rows
    return (cellWidth, cellHeight)

def drawPrims(app):
    for startpoints, endpoints in app.finalMoves:
        x1, y1 = getNodePosition(app, startpoints[1], startpoints[0])
        for endpoint in endpoints:
            x2, y2 = getNodePosition(app, endpoint[1], endpoint[0])
            drawLine( x1 + 50, y1 + 50, x2 + 50, y2 + 50, lineWidth = 100)

def isPointOnLineSegment(px,py,x1,y1,x2,y2):
    if min(x1,x2) <= px <= max(x1,x2) and min(y1,y2) <= py <= max(y1,y2):
        if (x2-x1) * (py-y1) == (y2-y1)*(px-x1):
            return True
    return False


def getPrimsTopandBottom(app):
    heroPos = (app.heroX,app.heroY)
    for startpoints,endpoints in app.finalMoves.items():
       x1,y1 = getNodePosition(app,startpoints[1],startpoints[0])
       for endpoint in endpoints:
            x2,y2 = getNodePosition(app,endpoint[1],endpoint[0])
            if isPointOnLineSegment(heroPos[0],heroPos[1],x1,y1,x2,y2):
                return True
    return False


def redrawAll(app):
    drawImage(app.gameBack,0,0)
    drawPrims(app)
    for node in app.graph.keys():
        nodePos = getNodePosition(app, node[0], node[1])
        if node == app.lastNodePosition:
            color = 'darkRed'
        else:
            color = 'black'
        n = Node(nodePos[0], nodePos[1],app.nodeSize,color)
        n.drawNode()  
    app.hero.drawCharacter()
    for enemy in app.enemies:
        enemy.drawCharacter()
    drawLabel(f'health:{app.health}',170,700,size=40, fill = 'fireBrick')
    if app.win:
        drawLabel('You Win!', app.width // 2, app.height // 2, size=40, fill='green')
    if app.lose:
        drawLabel('Game Over!', app.width // 2, app.height // 2, size=40, fill='red')

def onKeyPress(app, key):
    validMoves = getValidMoves(app)
    if validMoves:
        if key == 'left' and 'left' in validMoves:
            app.moving = True
            moveCharacter(app, -1, 0)
            checkCollision(app)
        elif key == 'right' and 'right' in validMoves:
            app.moving = True
            moveCharacter(app, 1, 0)
            checkCollision(app)
        elif key == 'up' and 'up' in validMoves:
            app.moving = True
            moveCharacter(app, 0, -1)
            checkCollision(app)
        elif key == 'down' and 'down' in validMoves:
            app.moving = True
            moveCharacter(app, 0, 1)
            checkCollision(app)
    #checkCollision(app)
    winCondition(app)
def getValidMoves(app):
    row, col = app.currNode
    moves = {
        'left': (row, col - 1),
        'right': (row, col + 1),
        'up': (row - 1, col),
        'down': (row + 1, col)
    }
    validMoves = []
    for direction, (newrow, newcol) in moves.items():
        v = app.finalMoves[(row,col)]
        for m, n in v:
            if m == newrow and n == newcol and (m,n):
                if getPrimsTopandBottom(app):
                    validMoves.append(direction)
    return validMoves


def moveCharacter(app, dcol, drow):
    newRow, newCol = app.currNode[0] + drow, app.currNode[1] + dcol
    if 0<=newRow<app.rows and 0<newCol<=app.cols and (newRow,newCol) in app.finalMoves.items():
        app.currNode = (newRow, newCol)
        newPos = getNodePosition(app, newRow, newCol)
        app.hero.moveTo(newPos)

# def moveCharacter(app, dcol, drow):
#     newRow, newCol = app.currNode[0] + drow, app.currNode[1] + dcol
#     if (newRow, newCol) in app.finalMoves:
#         app.currNode = (newRow, newCol)
#         newPos = getNodePosition(app, newRow, newCol)
# #        print("new pos is " , newRow, " ", newCol)
#         app.hero.moveTo(newPos)

#just use key press
#def onKeyRelease(app, key):
#    if key == 'm':
#        app.map = not app.map

def checkCollision(app):
    for enemy in app.enemies:
        if app.hero.collidesWith(enemy):
            #put in a set so that we can keep track of distinct enemies touched
            app.enemiesTouched.add(enemy)
            app.health-=1
            #stop when all enemies are touched
            if (len(app.enemiesTouched) == len(app.enemies)) or app.health == 0:
                app.lose = True
                app.stop()
def winCondition(app):
    if app.currNode == app.lastNodePosition:
        app.win = True
        app.stop()              

def getGridNode(app, pos):
        cellWidth, cellHeight = getCellSize(app)
        col = (pos[0] - app.boardLeft) // cellWidth
        row = (pos[1] - app.boardTop) // cellHeight
        return int(row), int(col)

class Node:
    def __init__(self, x, y, size,color = 'black'):
        self.x = x
        self.y = y
        self.size = size
        self.unit = 10 
        self.color = color
    def drawNode(self):
        drawRect(self.x, self.y, self.size, self.size,fill = self.color)

class Character:
    def __init__(self, pos, spritePath):
        self.x, self.y = pos
        self.targetPosX, self.targetPosY = pos
        self.spritePath = spritePath
        self.speed = 5
        self.currentTarget = None

    def drawCharacter(self):
        drawImage(self.spritePath, self.x + 30, self.y + 10, width=50, height=50)

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def moveTo(self, pos):
        self.targetPosX, self.targetPosY = pos
        self.currentTarget = pos

    def updatePosition(self):
        if self.currentTarget:
            deltaX = self.targetPosX - self.x
            deltaY = self.targetPosY - self.y
            distance = (deltaX**2 + deltaY**2)**0.5
            if distance > self.speed:
                directionX = deltaX / distance
                directionY = deltaY / distance
                self.x += directionX * self.speed
                self.y += directionY * self.speed
            else:
                self.x = self.targetPosX
                self.y = self.targetPosY
                self.currentTarget = None

    def collidesWith(self, other):
        spriteWidth = 50  # Assuming a width of 50 pixels for sprites
        spriteHeight = 50  # Assuming a height of 50 pixels for sprites
        return (self.x < other.x + spriteWidth and
                self.x + spriteWidth > other.x and
                self.y < other.y + spriteHeight and
                self.y + spriteHeight > other.y)

    
class Enemy(Character):
    def __init__(self, pos, gridPos, spritePath):
        super().__init__(pos, spritePath)
        self.gridPos = gridPos
        self.targetPosX, self.targetPosY = pos

    def enemyAI(self, app):
        row, col = self.gridPos
        possibleMoves = app.finalMoves.get((row, col), [])
        if possibleMoves:
            newGridPos = random.choice(list(possibleMoves))
            newRow, newCol = newGridPos[1], newGridPos[0]

            # Check if the new position is within bounds
            if 0<=newRow<=app.rows and 0<=newCol<app.cols and (newRow,newCol) in app.finalMoves:
                self.gridPos = (newRow, newCol)
                newPos = getNodePosition(app, newRow, newCol)
                self.moveTo(newPos)

    def updatePosition(self):
        if self.currentTarget:
            deltaX = self.targetPosX - self.x
            deltaY = self.targetPosY - self.y
            distance = (deltaX**2 + deltaY**2)**0.5
            if distance > self.speed:
                directionX = deltaX / distance
                directionY = deltaY / distance
                self.x += directionX * self.speed
                self.y += directionY * self.speed
            else:
                self.x = self.targetPosX
                self.y = self.targetPosY
                self.currentTarget = None

    # def enemyAI(self,app):
    #     print('enter')
    #     path = self.pathToHero(app)
    #     if path:
    #         newGridPos = path[0]
    #         newPos = getNodePosition(app,newGridPos[0],newGridPos[1])
    #         self.moveTo(newPos)
    #         self.gridPos = newGridPos
    #     print('end') 

    # def pathToHero(self,app,start,end, board):#BFS 
    #     start = start
    #     goal = end
    #     queue = collections.deque([start])
    #     visited = {start}
    #     prev = dict()
    #     dir = ['left', 'right', 'up', 'down']
    #     while queue:
    #         curNode = queue.popleft()
    #         x, y = curNode
    #         if (x, y) == goal:
    #             break
    #         for nextNode in board[curNode]:
    #             if nextNode not in visited:
    #                 queue.append(nextNode)
    #                 prev[nextNode] = curNode
    #                 visited.add(nextNode)
    #     path = []
    #     cur = goal
    #     while (cur != start):
    #         path.append(cur)
    #     cur = prev[cur]
    #     path.append(start)
    #     return path[::-1]

def main():
    runApp()

if __name__ == '__main__':
    main()
