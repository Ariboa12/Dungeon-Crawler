from cmu_graphics import *
from Prims import *
def onAppStart(app):
    app.rows = 9
    app.cols = 9
    app.points = list
    app.graph = Graph(app.rows,app.cols)
    app.finalMoves = prim(app.graph)
    app.width = 800
    app.height = 800
    app.nodeSize = 20
def drawPrims(app):
    for startpoints,endpoints in app.finalMoves.items():
        x1,y1 = startpoints[1] * (app.width//app.cols),startpoints[0]*(app.height//app.rows)
        for endpoint in endpoints:
            x2,y2 = endpoint[1] * (app.width//app.cols),endpoint[0]*(app.height//app.cols)
            drawLine(x1+30,y1+30,x2+30,y2+30,)

def redrawAll(app):
    for (pointX,pointY) in app.graph.keys():
       drawRect((pointX*(app.width//app.cols))+30,(pointY*(app.height//app.rows))+30,20,20,fill = 'red',border = 'black',align = 'center')
    drawLabel('prims',800,800)
    drawPrims(app)


def main():
    runApp()

if __name__ == '__main__':
    main()  

