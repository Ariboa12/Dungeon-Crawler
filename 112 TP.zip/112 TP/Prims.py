
# func given by Prof Lauren
#help for rewriting given by Anderson
# inspired by prims algorithm, uses unweighted points instead of weighted however
# working algorithm given help by Samuel, precollege student
import random
#generates all possible values
def Graph(rows,cols):
    # gives a 9x9 of the possible places to place our map
    graph = dict()
    visited = set()

    for row in range(rows):
        for col in range(cols):
            graph[(row,col)]= graphHelper(row,col,rows,cols)
    return  graph
    
def graphHelper(row,col,rows,cols):
    returnSet = set()
    possibleMoves = [(0,1),(0,-1),(1,0),(-1,0)]
    for (drow,dcol) in possibleMoves:
            ((newRow,newCol)) = ((row+drow,col+dcol))
            if 0<=newRow<rows and 0<=newCol<cols:
                returnSet.add((newRow,newCol))
    return returnSet

##helper function for prims##

def getUnvisitedPoints(graph,visited):
    newSet = set()
    for node in visited:
        for neighbor in graph[node]:
            if (neighbor not in visited):
                newSet.add(neighbor)
    return newSet

#prims, this is what helps generate my board

def prim(graph):#repeated (n) - 1 times
    '''for a larger board, some of the parts are disconnected 
        and they don't connect to the rest of the board'''
    start = (0,0)
    possiblePrimMoves = dict() # possiblemoves
    visited = set() # already visited
    Points = set() # have not visited
    visited.add(start)
    finalMoves = dict()
    Points = getUnvisitedPoints(graph,visited)
    
    while Points:
        cellToVisit = random.choice(list(Points))
        connectedVisited = []
        # look through the neighbors of the cell we want to add
        for neighbor in graph[cellToVisit]:
            # generate an array of the neighbors that are already part of the ST
            if (neighbor in visited):
                connectedVisited.append(neighbor)
        #pick a random node out of the ones in ST neighboring cellToVisit
        existingCell = random.choice(connectedVisited)
        # choose a random cell in the visited points
        visited.add(cellToVisit)
        finalMoves[cellToVisit] = finalMoves.get(cellToVisit, set()) | {existingCell}
        finalMoves[existingCell] = finalMoves.get(existingCell, set()) | {cellToVisit}
        Points = getUnvisitedPoints(graph, visited)
        
   
    return finalMoves



