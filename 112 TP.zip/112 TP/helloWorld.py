name = 'Ari Rajaram'
andrewID = 'arir'

print(f'My name is {name}')
print(f'My andrewID is {andrewID}')